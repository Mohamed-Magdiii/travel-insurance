# rest-apis-node
A basic boiler plate for nodejs for a quick start, configured  with mongodb, auth using jwt, and one crud for hotels added