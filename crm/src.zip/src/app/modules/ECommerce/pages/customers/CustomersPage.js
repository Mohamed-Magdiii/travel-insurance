import React from "react";
// import { Route } from "react-router-dom";
// import { ProductsFetchDialog } from "./products-fetch-dialog/ProductsFetchDialog";
import { CustomersCard } from "./CustomersCard";
// import { CustomersUIProvider } from "./CustomersUIContext";

export function CustomersPage() {
  return <CustomersCard />;
}
