import React from 'react'
import {UserCard} from './UserCard'
export  function UserPage() {
    
    
  return (

       <UserCard />
  )
}
