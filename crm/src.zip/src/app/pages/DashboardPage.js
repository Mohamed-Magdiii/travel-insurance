import React from "react";

export function DashboardPage() {
  return <></>;
}
